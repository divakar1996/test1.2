package program2;

import java.util.Scanner;

public class TestPlayer {
	public static void main(String[] args) {
		int matchesPlayed;
		int playedScore[];
		int input;
		Scanner scanner = new Scanner(System.in);
		CricketDb cricketDb = new CricketDb();
		System.out.println("Enter the no of Matches played by a criker:");
		matchesPlayed  = scanner.nextInt();
		playedScore = new int[matchesPlayed];
		System.out.println("Enter the Scores:");

		for (int i = 0; i < matchesPlayed; i++) {
			input = scanner.nextInt();
			playedScore[i] = input;

		}

		cricketDb.calculate(matchesPlayed, playedScore);

		scanner.close();
	}
}
