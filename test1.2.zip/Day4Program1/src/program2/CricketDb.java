package program2;

public class CricketDb {

	public void calculate(int matchesPlayed, int[] playedScore) {
		for (int i = 1; i < matchesPlayed - 2; i++) {
			if ((playedScore[i] - playedScore[i-1]) == (playedScore[i + 1] - playedScore[i]))/*
					|| (playedScore[i-1] == playedScore[i]) || (playedScore[i +1] == playedScore[i + 2]))*/ {
				playedScore[i ] = playedScore[i];
				playedScore[i-1] = -1;
				playedScore[i + 1] = -1;

			} else {
				playedScore[i-1] = playedScore[i-1];

			}

			/*
			 * if (playedScore[i + 2] - playedScore[i + 1] == 1) { System.out.println(i); i
			 * = i + 2; break;
			 * 
			 * } } else if (playedScore[i] == playedScore[i + 1]) { System.out.println(i);
			 * i=i+2;
			 * 
			 * }
			 */
		}

		for (int i = 0; i < matchesPlayed; i++) {

			if (playedScore[i] == -1) {
				

			}
			else
			{
				System.out.println(" " + playedScore[i]);
			}

		}

	}
}
